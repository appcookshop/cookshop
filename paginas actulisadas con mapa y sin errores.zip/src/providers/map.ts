export interface Maps {
  clickable?: boolean;
  editable?: boolean;
  radius?: number;
  visible?: boolean;
}
