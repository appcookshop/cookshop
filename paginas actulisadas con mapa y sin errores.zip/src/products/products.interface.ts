export interface Productos{
  nombre: string;
  marca: string;
  imagen: string;
}
