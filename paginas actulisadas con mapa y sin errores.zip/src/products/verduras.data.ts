export const VERDURAS =[
  {
    nombre: "Cebolla",
    proveedor: "GreenDay",
    imagen: "../assets/imgs/cebolla.jpg"
  },
  {
    nombre: "Cebolla",
    proveedor: "GreenDay",
    imagen: "../assets/imgs/cebolla.jpg"
  },
  {
    nombre: "Cebolla",
    proveedor: "GreenDay",
    imagen: "../assets/imgs/cebolla.jpg"
  }
]
