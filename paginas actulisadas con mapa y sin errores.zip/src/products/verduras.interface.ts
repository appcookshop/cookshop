export interface Verduras{
nombre: string;
proveedor: string;
imagen: string;
}
