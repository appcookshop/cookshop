

export const PRODUCTOS =[
  {
    nombre: "Frijoles",
    marca: "Tio Pelon",
    imagen: "../assets/imgs/FijolTioPelon.jpg"
  },
  {
    nombre: "Arroz",
    marca: "Tio Pelon",
    imagen: "../assets/imgs/ArrozTioPelon.png"
  },
  {
    nombre: "Frijoles",
    marca: "Tio Pelon",
    imagen: "../assets/imgs/FijolTioPelon.jpg"
  },
  {
    nombre: "Arroz",
    marca: "Tio Pelon",
    imagen: "../assets/imgs/ArrozTioPelon.png"
  },
  {
    nombre: "Frijoles",
    marca: "Tio Pelon",
    imagen: "../assets/imgs/FijolTioPelon.jpg"
  },
  {
    nombre: "Arroz",
    marca: "Tio Pelon",
    imagen: "../assets/imgs/ArrozTioPelon.png"
  }
]
