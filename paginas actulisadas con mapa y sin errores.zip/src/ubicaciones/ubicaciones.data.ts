export const UBICACIONES =[
  { lat:9.995134,
    lng:-84.661768,
    nombre: "Pali"
  },
  { lat:9.996043,
    lng:-84.664026,
    nombre: "MaxiPali"
  },
  { lat:9.990192,
    lng:-84.667138,
    nombre: "CompreBien"
  },
  { lat:9.991223,
    lng:-84.664838,
    nombre: "Empino"
  }
]
