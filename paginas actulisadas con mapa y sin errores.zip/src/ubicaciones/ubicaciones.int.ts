export interface Ubicaciones {
  lat:number;
  lng:number;
  nombre:string;
}
