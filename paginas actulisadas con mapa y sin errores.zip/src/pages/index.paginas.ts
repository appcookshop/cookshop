export { HomePage } from "./home/home";
export { RecipesPage } from "./recipes/recipes";
export { ShopPage } from "./shop/shop";
export { TabsPage } from "./tabs/tabs";
export  { ReciPage } from "./reci/reci";
export { InfoPage } from "./info/info";
export { RegisterPage } from "./register/register";
