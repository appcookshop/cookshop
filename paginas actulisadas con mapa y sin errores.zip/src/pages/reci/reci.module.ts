import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReciPage } from './reci';

@NgModule({
  declarations: [
    ReciPage,
  ],
  imports: [
    IonicPageModule.forChild(ReciPage),
  ],
})
export class ReciPageModule {}
