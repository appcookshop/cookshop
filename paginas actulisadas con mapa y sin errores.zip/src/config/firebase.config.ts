export const firebaseConfig = {
  apiKey: "AIzaSyDqhQcXWmTMcbkTnF8W8dZOs8eZv8MEnoo",
  authDomain: "cookshop-app.firebaseapp.com",
  databaseURL: "https://cookshop-app.firebaseio.com",
  projectId: "cookshop-app",
  storageBucket: "cookshop-app.appspot.com",
  messagingSenderId: "138951785010"
};
