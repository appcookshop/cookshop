export interface Receta{
  nombre: string;
  ingredientes: string;
  preparacion: string;
  imagen:string
}
