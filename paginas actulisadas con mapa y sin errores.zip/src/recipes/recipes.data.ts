
export const RECIPES =[

    {
    nombre: "Vinagreta de hierbas",
    ingredientes: "¼ taza de aceite de oliva ¼ taza de vinagre de vino tinto, ¼ taza de vino blanco 1 cdita. de orégano seco molido",
    preparacion: "En un tazón, mezcle todos los ingredientes. Rectifique la sazón con sal y pimienta.",
    imagen: "../assets/imgs/vina.jpg"
    },
    {
    nombre: "hierbas",
    ingredientes: "¼ taza de aceite de oliva ¼ taza de vinagre de vino tinto ¼ taza de vino blanco 1 cdita. de orégano seco molido",
    preparacion: "En un tazón, mezcle todos los ingredientes. Rectifique la sazón con sal y pimienta.",
    imagen: "../assets/imgs/EnsaladaSurimi.jpg"
    },
    {
    nombre: "Hierbitas",
    ingredientes: "¼ taza de aceite de oliva ¼ taza de vinagre de vino tinto ¼ taza de vino blanco 1 cdita. de orégano seco molido",
    preparacion: "En un tazón, mezcle todos los ingredientes. Rectifique la sazón con sal y pimienta.",
    imagen: "../assets/imgs/spaguetiTomate.jpg"
    },
    {
    nombre: "Vinagreta de hierbas",
    ingredientes: "¼ taza de aceite de oliva ¼ taza de vinagre de vino tinto ¼ taza de vino blanco 1 cdita. de orégano seco molido",
    preparacion: "En un tazón, mezcle todos los ingredientes. Rectifique la sazón con sal y pimienta.",
    imagen: "../assets/imgs/vina.jpg"
    },
    {
    nombre: "Vinagreta de hierbas",
    ingredientes: "¼ taza de aceite de oliva ¼ taza de vinagre de vino tinto ¼ taza de vino blanco 1 cdita. de orégano seco molido",
    preparacion: "En un tazón, mezcle todos los ingredientes. Rectifique la sazón con sal y pimienta.",
    imagen: "../assets/imgs/vina.jpg"
    },
    {
    nombre: "Vinagreta de hierbas",
    ingredientes: "¼ taza de aceite de oliva ¼ taza de vinagre de vino tinto ¼ taza de vino blanco 1 cdita. de orégano seco molido",
    preparacion: "En un tazón, mezcle todos los ingredientes. Rectifique la sazón con sal y pimienta.",
    imagen: "../assets/imgs/vina.jpg"
  }

/*
  {
  nombre: "Vinagreta de hierbas",
  ingredientes: "¼ taza de aceite de oliva ¼ taza de vinagre de vino tinto ¼ taza de vino blanco 1 cdita. de orégano seco molido",
  preparacion: "En un tazón, mezcle todos los ingredientes. Rectifique la sazón con sal y pimienta.",
  imagen: "../assets/imgs/vina.jpg"
  },

{
  nombre: "Receta de Sándwich de pollo light - Con pollo al limón",
  ingredientes:
"½ Pechuga de pollo a la plancha
 1 Manojo de Cilantro fresco
 ½ Limón
 1 Pizca de Sal y Pimienta
 1 Trozo de Queso fresco
 3 Rebanadas de Pan integral
 Extras opcionales
 2 Hojas de Lechuga
 ½ Aguacate
 2 Rodajas de Tomate para ensalada",
  preparacion: "usaremos una pechuga de pollo a la plancha desmenuzada aunque también puedes usar cualquier tipo de restos de pollo que tengas a mano lo importante es que sea pollo con un sabor plano.
Picamos el cilantro finamente y también aprovechamos para exprimir los limones. Si sigues mis recetas sabrás que la combinación de cilantro y limón es un clásico para mi, queda bien con todo y da un sabor muy fresco a los platos, como en la ensalada de garbanzos y aguacate.
Hacemos la mezcla de pollo para el relleno de nuestro sándwich light, con el cilantro el limón y sazonamos con una pizca de sal y pimienta al gusto.
Ahora vamos con el queso a la plancha yo he utilizado una loncha gruesa de queso latina, que es un queso fresco ligeramente salado y que queda perfecto pasados unos segundos por la plancha.
Para armar el sándwich, empezamos colocando una rebanada de pan de molde y encima el queso luego otra rebanada de pan y la mezcla de pollo, limón y cilantro. Terminamos con otra capa de pan y listo.
En este punto puedes preparar y añadir el resto de extras para el sándwich de pollo, yo lo hice con pocos ingredientes pero puede quedar aún mejor con unas hojas de lechuga y unas cuantas tajadas de aguacate.
Divídelo en cuatro para que te lo puedas comer fácilmente y ¡buen provecho! Este sándwich de pollo light con pollo al limón no solo está buenísimo, sino que es fresco y ligero, así que podrás incluirlo en tu dieta sin problemas.",
  imagen: "../assets/imgs/sandwichPollo.jpg"
  },

{
  nombre: "Receta de Sandwich de tempeh - ¡El bocadillo vegetal vegano perfecto!",
  ingredientes: " 3 Rebanadas de Pan integral
 2 Lonchas de Tempeh
 4 Hojas de Lechuga variada
 2 Cucharadas soperas de Cilantro fresco
 5 Rodajas de Pepino
 2 Cucharadas soperas de Mayonesa vegetal
 1 Cucharada sopera de Brotes de alfalfa
 1 Cucharada sopera de Aceite de sésamo
 1 Cucharadita de Vinagre de Arroz
 2 Cucharaditas de Salsa de soja
 ½ Cucharadita de Azúcar moreno",
  preparacion: "En primer lugar, empezaremos a hacer este sándwich de tempeh preparando la vinagreta. Macera el tempeh mezclando en en bol la salsa de soja, el aceite de sésamo, el vinagre de arroz y el azúcar. Remueve bien para incorporar los ingredientes. Pon las lonchas de tempeh en el bol y deja macerar media hora.
2
A continuación, calienta una sartén y cocina el tempeh macerado por ambos lados hasta que se dore un poco.
3
Tuesta las rebanadas de pan y úntalas con la mayonesa vegana. En la rebanada inferior coloca varias hojas de lechuga, los brotes y las rodajas de pepino. Coloca la segunda rebanada de pan, el resto de lechuga, el tempeh y la última rebanada de pan.
En realidad, puedes rellenar de cualquier hortaliza que te guste este sándwich vegetal vegano.
4
Corta el sándwich de tempeh en 2 triángulos y sírvelo acompañado con unas patatas al horno con romero por ejemplo.",
  imagen: "../assets/imgs/sandwichTempeh.jpg"
  },

{
  nombre: "Receta de Pollo al ast casero (o pollo asado con patatas) - ¡De rechupete!",
  ingredientes: " 1 Pollo limpio
 2 Sobres de Ajos
 1 Pellizco de Sal
 1 Pizca de Pimienta negra molida
 50 Gramos de Mantequilla
 1 Cucharada sopera de Tomillo seco
 4 Hojas de Laurel
 800 Gramos de Patatas
 1 Chorro de Aceite de oliva virgen",
  preparacion: "sos a seguir para hacer esta receta | 1 hora 30 minutos
1
Para preparar nuestro pollo al ast casero, primero partiremos una de las cabezas de ajos por la mitad.
La otra cabeza de ajos, la pelamos y separamos la mitad de los dientes de ajos, que laminaremos, y la otra mitad de los dientes que machacaremos en el mortero.
Fundir la mantequilla en el microondas y añadir el tomillo, los ajos machacados y dos hojas de laurel troceadas.
Truco: Estas son las especias para pollo al ast que vamos a utilizar pero tú puedes agregar las que prefieras.
El pollo deberá estar limpio por dentro y por fuera y sin vísceras. Salpimentar tanto fuera como por dentro y embadurnar con la mezcla de condimento de pollo al ast que hemos preparado antes de mantequilla, ajo y tomillo.
Truco: Hay que untar todo el pollo, también por dentro.
Pelar y trocear las patatas en gajos y poner en una fuente apta para el horno junto con las mitades de la cabeza de ajos. Colocar encima el pollo. Espolvorear con los ajos laminados y añadir las otras dos hojas de laurel.
Rociar el pollo al ast casero con un buen chorro de aceite de oliva virgen y hornear en horno precalentado a 200 ºC con calor arriba y abajo durante aproximadamente 1 hora y cuarto o una hora y media, todo dependerá del tamaño del ave y de vuestro horno. Así nos quedará un pollo asado con en los asadores.
Truco: Dar la vuelta de vez en cuando al pollo asado, para que se haga de manera uniforme, y aprovechar para regarlo con el líquido resultante de la cocción.
Esta forma de hacer el pollo asado al horno jugoso está para chuparse los dedos, os lo garantizo. Si te animas a hacerlo, me encantaría que me enviaras una foto. Si quieres más recetas como este delicioso pollo asado con patatas, te invito a mi blog Cakes para ti.",
  imagen: "../assets/imgs/PolloAstCasero.jpg"
  },


{
  nombre: "Receta de Pollo relleno de ciruelas y nueces",
  ingredientes: "1 Unidad de Pollo entero sin visceras
 3 Latas de Cerveza rubia
 2 Unidades de Pimiento o pimentón rojo
 1 Cucharada sopera de Mostaza
 2 Ramas de Romero
 1 Copa de Vino blanco
 2 Unidades de Cebolla blanca
 1 Cucharadita de Pasta de ajo
Para el relleno
 100 Gramos de Ciruelas pasas
 100 Gramos de Arandanos
 100 Gramos de Uvas pasas
 3 Unidades de Manzanas rojas
 2 Unidades de Zanahoria
 100 Gramos de Apio
 50 Gramos de Nuez del brasil
 50 Gramos de Almendras
 50 Gramos de Maní
 1 Pizca de Sal
 1 Pizca de Pimienta negra
 1 Taza de Miel de abejas",
preparacion: "Vamos a retirar un poco el exceso de grasa de nuestra pieza de pollo.
Desecha esta grasa pues no va hacer necesaria en la preparación.
Para hacer el marinado, lleva la cebolla, la pimienta y la mitad de una cerveza a un procesador de comida. Tritura bien todos los ingredientes.
Lleva el pollo a un tazón hondo y baña con el marinado que preparamos anteriormente. Añade el resto de las cervezas, pasta de ajo, pimienta negra, mostaza y vino blanco. Mezcla bien todos los ingredientes.
Por último añade el romero, recuerda que éste es una hierba aromática muy fuerte, así que no uses mucho para que el sabor no se altere tanto. El tiempo de marinado es a tu elección, en lo personal yo recomiendo mínimo unas 24 a máximo 48 horas en la heladera o refrigerador para que penetre en la carne del pollo todo el sabor de la salsa.
Truco: Si deseas marinarlo una hora o dos es válido.
Una vez pase el tiempo del marinado retira el pollo de la heladera o refrigerador.
Para realizar el relleno de nuestro pollo prealista los ingredientes marcados para el relleno. Recuerda, que al igual que para el pavo relleno de Navidad, estos pueden variar según tu elección
Pelas las manzanas. Lleva una olla honda a fuego medio con una cucharadita de mantequilla y saltéalas con sal, pimienta negra y pasta de ajo al gusto.
Una vez notes que las manzanas se están caramelizando cubre con agua y adiciona alguna hierva aromática como tomillo u orégano. Deja cocinar a fuego medio durante 15 minutos aproximadamente. Apaga el fuego.
En un bol agrega las ciruelas pasas, arándanos y uvas pasas.
Adiciona los frutos secos y mezcla con las manzanas previamente salteadas.
Mezcla bien los ingredientes de nuestro relleno y espera a que éste se enfríe. El líquido de la cocción de las manzanas ayudará a hidratar el resto de los ingredientes.
Pica los frutos secos (almendras, maní y nuez del brasil).
Mezcla los frutos secos con las manzanas e integra bien todos los ingredientes de nuestra receta de Acción de Gracias.
Lo ideal es obtener un relleno como se observa en la fotografía, recuerda que puedes modificar los sabores. agregando más o menos ingredientes que sean de tu agrado.
Lleva nuestro pollo entero a una mesa de trabajo una vez transcurra el tiempo en que lo hayas marinado.
Rellena con la mezcla como se observa en la fotografía. El relleno de manzana con frutos secos resulta realmente exquisita.
Una vez relleno el pollo, con ayuda de una aguja muy gruesa e hilo vamos a coser el hueco por donde rellenamos.
Con el fin de que nuestro pollo mantenga su forma, ata con hilo las patas y las alas como se muestra en la fotografía. De esta manera quedarán juntas al momento de la cocción en el horno.
Pela la zanahoria y corta en trozos grandes, haz lo mismo haz con el apio. Colócalos en la refractaria donde vamos a cocinar el pollo de acción de gracias.
Introduce el pollo entero y agrega sal y pimienta negra al gusto. Lo que va hacer los vegetales es que van aromatizar nuestra receta de pollo de Acción de Gracias.
Añade el marinado donde estuvo reposando el pollo a la refractaria. Agrega encima una rama de romero.
Cubre con papel aluminio la refractaria para que el pollo se mantenga húmedo durante la cocción. Precalienta un horno a 250ºC y cocina el pollo durante unos 90 minutos aproximadamente.
Retira el pollo relleno del horno, vas a observar que tienes una receta muy jugosa y un aroma increíble.
Retira las cuerdas que atan las alas y patas de pollo, baña con miel e introduce por unos 10 minutos más. Con este paso le daremos un toque dorado al pollo.
Una vez se haya dorado estamos listos para servir. El jugo que queda de en la refractaria puedes colarlo y servirlo a la mesa o realizar una deliciosa salsa con esta base, pues contiene bastante sabor.
Sirve el pollo relleno de ciruelas y nueces y acompaña con una ensalada de manzana y roquefort. Este plato de pollo relleno es ideal para fiestas especiales como la cena de Navidad o la cena de Acción de Gracias una opción más económica que el pavo pero igual de elegante y deliciosa. Si deseas más recetas para navidad o acción de gracias y tienes algún comentario o inquietud, escríbenos.",
  imagen: "../assets/imgs/polloCiruela.jpg"
  },

{
  nombre: "Receta de Pulpos encebollados",
  ingredientes: "500 Gramos de Pulpos pequeños o medianos
 1 Vaso pequeño de Vino blanco
 2 Vasos pequeños de Agua
 3 Cebollas
 4 Dientes de Ajo
 1 Hoja de Laurel
 2 Guindillitas
 3 Tomates maduros
 1 Chorro de Aceite de oliva virgen
 1 Pizca de Sal",
  preparacion: "Pela y corta la cebolla en juliana. Dale un golpe a los dientes de ajo para que se abran con la parte plana de un cuchillo.
Para preparar el sofrito de los pulpitos encebollados pon una sartén con aceite al fuego y sofríe los ajos hasta que estén dorados. Rehoga en el mismo aceite la cebolla a fuego suave.
Cuando la cebolla esté transparente y bien pochada, añade las guindillas, la hoja de laurel y los tomates rallados, remueve todo junto y sube el fuego para que se cocine el tomate unos minutos. Añade el vasito de vino blanco y los de agua, remueve y deja a fuego fuerte unos segundos hasta que hierva, luego baja el fuego.

Mientras se guisa la cebolla con el tomate para los pulpitos en salsa, vamos a limpiarlos:
Los pulpos que yo he cocinado son un poco grandes, por lo que les he quitado la piel, si los tuyos son pequeños no hace falta quitársela, los enjuagas bien y los secas para que no tengan agua y ya está.
Pon un poco de aceite en una sartén y saltea los pulpitos limpios, dales unas vueltas, saca y reserva.
Cuando la cebolla esté rehogada, añade los pulpitos limpios, tapa la sartén y deja que se cuezan a fuego lento durante unos 20 minutos, o hasta que veas que están tiernos y no queda caldo.
Sirve los pulpos encebollados calientes. Y si te ha gustado esta receta de pulpitos en salsa, has probado a hacerla o piensas que podría mejorarla, no dudes en darme tu opinión.",
  imagen: "../assets/imgs/pulpoEncebollados.jpg"
  },

{
  nombre: "Receta de Espaguetis con tomate natural y albahaca",
  ingredientes: " 400 Gramos de Espaguetis
 3 Tomates maduros
 1 Cebolleta
 3 Dientes de Ajo
 1 Puñado de Hojas de Albahaca fresca
 1 Pizca de Sal al gusto
 1 Pizca de Pimienta negra recién molida al gusto
 50 Gramos de Mantequilla
 1 Cucharada sopera de Aceite de oliva
 1 Puñado de Escamas de Queso parmesano",
  preparacion: "
Para hacer la guarnición de tomate natural y albahaca de nuestros espaguetis, el primero paso es derretir la mantequilla en una sartén junto con el aceite para evitar que se queme, cuando lo tengamos, sofreímos los ajos.
Cuando veamos que el ajo comienza a dorarse, incorporamos la cebolleta previamente cortada en juliana.
Mientras, pelamos los tomates, los cortamos en gajos y aprovechamos para quitar todas las semillas.
Cuando la cebolla esté casi pochada, añadimos los tomates y removemos todo el sofrito.
Salpimentamos al gusto con sal y pimiento recién molida y mantenemos la cocción un par de minutos, removiendo de forma constante.
Ya para terminar y darle el toque especial a nuestra salsa de tomate natural par pasta, retiramos la sartén del fuego, añadimos las hojas de albahaca y removemos bien.
Mientras hacemos la salsa, cocemos los espaguetis de forma tradicional y los dejamos el tiempo que nos marque el fabricante o a nuestro gusto. Lo ideal es que queden al dentes.
Lista la pasta y la salsa ya solo queda emplatar y añadir unas escamas de queso parmesano para decorar. Espero que os animéis a hacer estos estupendos espaguetis con tomate natural y albahaca y que os gusten. ¡Que aproveche!",
  imagen: "../assets/imgs/spaguetiTomate.jpg"
  },

{
  nombre: "Receta de Ensalada de surimi y manzana - ¡Lista en 5 minutos!",
  ingredientes: " 1 Lechuga
 10 Palitos de Cangrejo o Ssurimi
 1 Manzana
 1 Lata de Aceitunas verdes sin hueso
 1 Puñado de Pipas de girasol peladas
 100 Gramos de Queso gouda
 1 Cucharadita de Especias para ensalada
 1 Pizca de Sal
 1 Chorro de Aceite de oliva virgen extra",
  preparacion: "El primer paso para hacer nuestra ensalada con palitos de cangrejo será partir la lechuga y lavarla bien. Centrifugamos y reservamos.
Lavamos la manzana, la partimos en trocitos y la ponemos en un bol amplio. Hacemos lo mismo con los palitos de surimi, partiéndolos en trozos más o menos del mismo tamaño y los añadimos al bol.
Escurrimos las aceitunas y las ponemos en la ensaladera.
Cortamos en daditos el queso y lo añadimos junto con la lechuga muy bien escurrida y un puñadito de pipas de girasol peladas para ensalada.
Aliñamos con sal, aceite de oliva y una cucharadita de especias para ensalada. Mezclamos bien hasta comprobar que todos los ingredientes se han repartido de forma uniforme y listo.
La mezcla de sabores en esta ensalada de surimi y manzana es deliciosa, como vez es muy fácil de hacer, es ligera y te servirá para cualquier ocasión.
También puedes aliñarla con un toque de mayonesa casera, aunque si te sobraron palitos de cangrejo, puedes hacer otros platos como unas tortitas de surimi o un original sándwich con cangrejo y gambas.",
  imagen: "../assets/imgs/EnsaladaSurimi.jpg"
  }
*/
]
